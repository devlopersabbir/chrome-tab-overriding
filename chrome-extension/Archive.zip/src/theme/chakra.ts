/**
 * Type your theme config file code
 * like global style
 */
